﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace Calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            textBox1.Text += "0";
        }
        private void button1_Click_1(object sender, EventArgs e)
        {
            textBox1.Text += "1";
        }
        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text += "2";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text += "3";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox1.Text += "4";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox1.Text += "5";
        }

        private void button6_Click(object sender, EventArgs e)
        {
            textBox1.Text += "6";

        }

        private void button7_Click(object sender, EventArgs e)
        {
            textBox1.Text += "7";

        }

        private void button8_Click(object sender, EventArgs e)
        {
            textBox1.Text += "8";

        }

        private void button9_Click(object sender, EventArgs e)
        {
            textBox1.Text += "9";

        }

        private void button11_Click(object sender, EventArgs e)
        {   // the sign +/-
            textBox1.Text += "-";
        }
        private void button12_Click(object sender, EventArgs e)
        {
            textBox1.Text += ".";
        }
        
        private void button14_Click(object sender, EventArgs e)
        {
            textBox1.Text += "+";
        }

        private void button15_Click(object sender, EventArgs e)
        {
            textBox1.Text += "-";
        }

        private void button16_Click(object sender, EventArgs e)
        {
            textBox1.Text += "*";
        }

        private void button17_Click(object sender, EventArgs e)
        {
            textBox1.Text += "/";
        }

        private void button18_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text.Remove( textBox1.Text.Length - 1 );  // C: undo
        }

        private void button19_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";    //AC: Reset the screen
        }
        private void button20_Click(object sender, EventArgs e)
        {
            textBox1.Text += "^2";
        }
       
        private void button13_Click(object sender, EventArgs e)
        {  // to get the result
            String exp = textBox1.Text;
            Match Reg = Regex.Match(exp, @"\b(((\-?[0-9]*)\.?([1-9]+)(^2)*(\+|\-|\*|/)(\-?[0-9]*)\.?([1-9]+)(^2)*)|(\-?[0-9]*)\.?([1-9]+)(^2)*)\b");
            if (!Reg.Success) { textBox1.Text = "Syntax error1"; }
            else
            {
                String x = "";
                String y = "";
                String op = "";
                Double temp1 = 0;
                Double temp2 = 0;
                
                try
                {   int i = 0;
                    if (exp[0] == '-') { x += exp[0]; i = 1; }

                    for ( i=i ; i < exp.Length; i++)
                    {
                        if (isdigit(exp[i]))
                        {

                            if (op == "")
                                x += exp[i];
                            else
                                y += exp[i];
                        }
                        else if (isop(exp[i]))
                        {
                            if (op == "")
                                op += exp[i];
                            else
                            {
                                switch (op[0])
                                {
                                    case '+':
                                        Double.TryParse(x, out temp1);
                                        Double.TryParse(y, out temp2);
                                        x = ""; y = "";
                                        x += temp1 + temp2;
                                        break;

                                    case '-':
                                        Double.TryParse(x, out temp1);
                                        Double.TryParse(y, out temp2);
                                        x = ""; y = "";
                                        x += temp1 - temp2;
                                        break;

                                    case '*':
                                        Double.TryParse(x, out temp1);
                                        Double.TryParse(y, out temp2);
                                        x = ""; y = "";
                                        x += temp1 * temp2;
                                        break;

                                    case '/':
                                        if (temp2 != 0.0)
                                        {
                                            Double.TryParse(x, out temp1);
                                            Double.TryParse(y, out temp2);
                                            x = ""; y = "";
                                            x += temp1 / temp2;
                                        }
                                        else { textBox1.Text = "Error, Divide by Zero "; break; }
                                        break;
                                }
                                op = "";
                                op += exp[i];
                            }
                        }
                        else if (exp[i] == '.') 
                        {
                            if (op == "")
                                x += exp[i];
                            else
                                y += exp[i]; 
                        }
                        else if (exp[i] == '^')
                        {
                            Double.TryParse(x, out temp1);
                            x = "";
                            x += temp1 * temp1;
                            i++;
                        }
                    } // end for 

                    if (op != "")
                        switch (op[0])
                        {
                            case '+':
                                Double.TryParse(x, out temp1);
                                //MessageBox.Show(x);
                                Double.TryParse(y, out temp2);
                                x = ""; y = "";
                                x += temp1 + temp2;
                                textBox1.Text = x;
                                break;

                            case '-':
                                Double.TryParse(x, out temp1);
                                Double.TryParse(y, out temp2);
                                x = ""; y = "";
                                x += temp1 - temp2;
                                textBox1.Text = x;
                                break;

                            case '*':
                                Double.TryParse(x, out temp1);
                                Double.TryParse(y, out temp2);
                                x = ""; y = "";
                                x += temp1 * temp2;
                                textBox1.Text = x;
                                break;

                            case '/':
                                Double.TryParse(x, out temp1);
                                Double.TryParse(y, out temp2);
                                if (temp2 != 0.0)
                                {
                                    Double.TryParse(x, out temp1);
                                    Double.TryParse(y, out temp2);
                                    x = ""; y = "";
                                    x += temp1 / temp2;
                                    textBox1.Text = x;
                                }
                                else { textBox1.Text = "Error, Divide by Zero "; break; }
                                break;
                        } //end switch

                    else  //op == "" means we used ^2 
                    {
                        textBox1.Text = x;
                    }

                }  // end Try
                catch
                {
                    textBox1.Text = "Synatx error";
                }
            } //end else, valid regular expression
        } //end the button function
        private Boolean isdigit(char x)
        { 
            if(x=='0' || x=='1' ||x=='2' ||x=='3' ||x=='4' ||x=='5' ||x=='6' ||x=='7' ||x=='8' ||x=='9')
                return true;
            
            else return false;
        }
        private Boolean isop(char x)
        {
            if (x == '+' || x == '-' || x == '/' || x == '*' )
                return true;

            else return false;
        }  
    }
}
